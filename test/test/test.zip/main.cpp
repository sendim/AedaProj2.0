#pragma once
#include "menu.h"

int main() {


	cout << "Protecao civil - Trabalho de AEDA" << endl << endl;

	cout << "Trabalho desenvolvido por Henrique Sendim, Luis Borges e Mariana Neto." << endl << endl;

	menuInicial();




	return 0;

}
