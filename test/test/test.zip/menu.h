#pragma once

#include "ServicoEmergencia.h"



void menuInicial();
void adicionarAcidente();
void verOsPostos();
void addIncendio();
void addAssalto();
void verOsAcidentes();
void adicionarIncendioFloresta();
void adicionarIncendioApartamento();
void adicionarIncendioMoradia();
void adicionarAssaltoComercial();
void adicionarAssaltoParticular();
void adicionarAcidenteViacao();

